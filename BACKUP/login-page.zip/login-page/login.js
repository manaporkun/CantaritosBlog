const loginForm = document.getElementById("form");
const loginButton = document.getElementById("submit");
const loginErrorMsg = document.getElementById("error-message");

loginButton.addEventListener("click", (e) => {

    e.preventDefault();

    const username = loginForm.username.value;
    const password = loginForm.password.value;

    if (username === "admin" && password === "admin") {

        alert("You have successfully logged in.");
        location.reload();
    } else {

        loginErrorMsg.style.opacity = 1;
    }
})
